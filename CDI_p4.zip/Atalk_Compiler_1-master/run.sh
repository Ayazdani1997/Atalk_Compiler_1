rm *.class
antlr4 Atalk.g4
antlr4 Atalk_p2.g4
javac *.java
java Atalk testcases/test5.in
