public class NotPositiveArraySizeException extends Exception{
}