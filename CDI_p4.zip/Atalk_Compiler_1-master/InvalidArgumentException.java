public class InvalidArgumentException extends Exception {
}