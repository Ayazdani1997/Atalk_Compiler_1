public class AtLeastOneActorException extends Exception {
	
}